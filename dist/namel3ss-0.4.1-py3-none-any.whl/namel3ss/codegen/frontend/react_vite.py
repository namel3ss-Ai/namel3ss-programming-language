"""Generate a Vite + React + TypeScript frontend."""

from __future__ import annotations

import json
import re
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

from namel3ss.ast import App, Page
from namel3ss.ast.pages import ShowChart, ShowForm, ShowTable, ShowText, ToastOperation

from .assets import generate_styles
from .preview import PreviewDataResolver
from .slugs import slugify_page_name, slugify_route


@dataclass
class ReactPage:
    """Metadata required to render a React page component."""

    component_name: str
    file_name: str
    primary_route: str
    extra_routes: List[str]
    backend_slug: str
    definition: Dict[str, Any]


def generate_react_vite_site(app: App, output_dir: str, *, enable_realtime: bool = False) -> None:
    """Generate a Vite + React + TypeScript project for ``app``."""

    out = Path(output_dir)
    src_dir = out / "src"
    components_dir = src_dir / "components"
    pages_dir = src_dir / "pages"
    lib_dir = src_dir / "lib"

    for path in (out, src_dir, components_dir, pages_dir, lib_dir):
        path.mkdir(parents=True, exist_ok=True)

    preview_provider = PreviewDataResolver(app)

    page_builds: List[ReactPage] = []
    nav_links: List[Dict[str, str]] = []

    if not app.pages:
        placeholder = _build_placeholder_page()
        page_builds.append(placeholder)
        nav_links.append({"label": "Home", "path": "/"})
    else:
        for index, page in enumerate(app.pages):
            build = _build_page_definition(
                app,
                page,
                index,
                preview_provider,
                enable_realtime=enable_realtime,
            )
            page_builds.append(build)
            nav_links.append({"label": page.name, "path": build.definition["route"]})

    _write_package_json(out)
    _write_tsconfig(out)
    _write_tsconfig_node(out)
    _write_vite_config(out)
    _write_index_html(out, app.name)
    _write_main_tsx(src_dir)
    _write_index_css(src_dir, app)
    _write_navigation(lib_dir, nav_links)
    _write_toast_component(components_dir)
    _write_layout_component(components_dir)
    _write_chart_widget(components_dir)
    _write_table_widget(components_dir)
    _write_form_widget(components_dir)
    _write_text_widget(components_dir)
    _write_realtime_hook(lib_dir)
    _write_client_lib(lib_dir)
    _write_app_tsx(src_dir, page_builds)

    for build in page_builds:
        _write_page_component(pages_dir, build)


def _build_placeholder_page() -> ReactPage:
    definition = {
        "slug": "index",
        "route": "/",
        "title": "Welcome",
        "description": "Add pages to your .n3 program to populate the React UI.",
        "reactive": False,
        "realtime": False,
        "widgets": [
            {
                "id": "text_1",
                "type": "text",
                "text": "Namel3ss generated this placeholder because no pages were defined.",
                "styles": {"align": "center"},
            }
        ],
        "preview": {},
    }
    return ReactPage(
        component_name="IndexPage",
        file_name="index",
        primary_route="/",
        extra_routes=[],
        backend_slug="index",
        definition=definition,
    )


def _build_page_definition(
    app: App,
    page: Page,
    index: int,
    preview_provider: PreviewDataResolver,
    *,
    enable_realtime: bool,
) -> ReactPage:
    backend_slug = slugify_page_name(page.name, index)
    raw_route = page.route or "/"
    route = _normalize_route(raw_route)
    slug = slugify_route(raw_route)
    if index > 0 and route == "/":
        inferred = slug if slug != "index" else f"page_{index + 1}"
        route = f"/{inferred}"
        slug = inferred

    file_name = slug or ("page" + str(index + 1))
    if index == 0:
        file_name = "index"

    component_name = _make_component_name(file_name, index)
    widgets, preview_map = _collect_widgets(page, preview_provider)

    primary_route = "/"
    extra_routes: List[str] = []
    if route != "/":
        if index == 0:
            extra_routes.append(route)
        else:
            primary_route = route

    definition = {
        "slug": backend_slug,
        "route": route,
        "title": page.name,
        "description": page.layout.get("description") if isinstance(page.layout, dict) else None,
        "reactive": bool(page.reactive),
        "realtime": bool(enable_realtime and page.reactive),
        "widgets": widgets,
        "preview": preview_map,
    }

    return ReactPage(
        component_name=component_name,
        file_name=file_name,
        primary_route=primary_route,
        extra_routes=extra_routes,
        backend_slug=backend_slug,
        definition=definition,
    )


def _collect_widgets(
    page: Page,
    preview_provider: PreviewDataResolver,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    widgets: List[Dict[str, Any]] = []
    preview_map: Dict[str, Any] = {}
    counters = {
        "text": 0,
        "table": 0,
        "chart": 0,
        "form": 0,
    }

    for statement in page.statements:
        if isinstance(statement, ShowText):
            counters["text"] += 1
            widget_id = f"text_{counters['text']}"
            widgets.append(
                {
                    "id": widget_id,
                    "type": "text",
                    "text": statement.text,
                    "styles": statement.styles or {},
                }
            )
        elif isinstance(statement, ShowTable):
            counters["table"] += 1
            widget_id = f"table_{counters['table']}"
            preview = preview_provider.table_preview(statement)
            preview_map[widget_id] = preview
            widgets.append(
                {
                    "id": widget_id,
                    "type": "table",
                    "title": statement.title,
                    "source": {
                        "kind": statement.source_type,
                        "name": statement.source,
                    },
                    "columns": statement.columns or preview.get("columns", []),
                }
            )
        elif isinstance(statement, ShowChart):
            counters["chart"] += 1
            widget_id = f"chart_{counters['chart']}"
            preview = preview_provider.chart_preview(statement)
            preview_map[widget_id] = preview
            widgets.append(
                {
                    "id": widget_id,
                    "type": "chart",
                    "title": statement.heading,
                    "chartType": statement.chart_type,
                    "source": {
                        "kind": statement.source_type,
                        "name": statement.source,
                    },
                    "x": statement.x,
                    "y": statement.y,
                }
            )
        elif isinstance(statement, ShowForm):
            counters["form"] += 1
            widget_id = f"form_{counters['form']}"
            success_message: str | None = None
            for op in statement.on_submit_ops:
                if isinstance(op, ToastOperation):
                    success_message = op.message
                    break
            preview_map[widget_id] = {
                "fields": [
                    {"name": field.name, "type": field.field_type}
                    for field in statement.fields
                ]
            }
            widgets.append(
                {
                    "id": widget_id,
                    "type": "form",
                    "title": statement.title,
                    "fields": [
                        {"name": field.name, "type": field.field_type}
                        for field in statement.fields
                    ],
                    "successMessage": success_message,
                }
            )

    return widgets, preview_map


def _normalize_route(route: str | None) -> str:
    value = (route or "").strip()
    if not value:
        return "/"
    if not value.startswith("/"):
        value = "/" + value
    return value


def _make_component_name(base: str, index: int) -> str:
    cleaned = re.split(r"[^A-Za-z0-9]+", base)
    parts = [part for part in cleaned if part]
    if not parts:
        parts = ["Index"]
    name = "".join(part.capitalize() for part in parts)
    if not name or name.lower() == "index":
        name = "Index"
    suffix = "Page"
    if not name.endswith(suffix):
        name = f"{name}{suffix}"
    if index == 0:
        return "IndexPage"
    return name


def _write_package_json(out: Path) -> None:
    package = {
        "name": "namel3ss-react-frontend",
        "private": True,
        "version": "0.1.0",
        "type": "module",
        "scripts": {
            "dev": "vite",
            "build": "tsc && vite build",
            "preview": "vite preview",
        },
        "dependencies": {
            "react": "^18.3.1",
            "react-dom": "^18.3.1",
            "react-router-dom": "^6.28.0",
        },
        "devDependencies": {
            "@types/node": "^20.11.30",
            "@types/react": "^18.2.73",
            "@types/react-dom": "^18.2.24",
            "@vitejs/plugin-react": "^4.2.1",
            "typescript": "^5.4.5",
            "vite": "^5.3.1",
        },
    }
    _write_file(out / "package.json", json.dumps(package, indent=2) + "\n")


def _write_tsconfig(out: Path) -> None:
    tsconfig = {
        "compilerOptions": {
            "target": "ESNext",
            "useDefineForClassFields": True,
            "module": "ESNext",
            "moduleResolution": "Node",
            "strict": True,
            "jsx": "react-jsx",
            "resolveJsonModule": True,
            "isolatedModules": True,
            "esModuleInterop": True,
            "skipLibCheck": True,
        },
        "include": ["src"],
        "references": [{"path": "./tsconfig.node.json"}],
    }
    _write_file(out / "tsconfig.json", json.dumps(tsconfig, indent=2) + "\n")


def _write_tsconfig_node(out: Path) -> None:
    tsconfig_node = {
        "compilerOptions": {
            "composite": True,
            "module": "ESNext",
            "moduleResolution": "Node",
            "allowSyntheticDefaultImports": True,
        },
        "include": ["vite.config.ts"],
    }
    _write_file(out / "tsconfig.node.json", json.dumps(tsconfig_node, indent=2) + "\n")


def _write_vite_config(out: Path) -> None:
    content = textwrap.dedent(
        """
        import { defineConfig } from "vite";
        import react from "@vitejs/plugin-react";

        export default defineConfig({
          plugins: [react()],
          server: {
            proxy: {
              "/api": {
                target: "http://localhost:8000",
                changeOrigin: true,
              },
              "/ws": {
                target: "http://localhost:8000",
                ws: true,
              },
            },
          },
        });
        """
    ).strip() + "\n"
    _write_file(out / "vite.config.ts", content)


def _write_index_html(out: Path, title: str) -> None:
    content = textwrap.dedent(
        f"""
        <!doctype html>
        <html lang=\"en\">
          <head>
            <meta charset=\"UTF-8\" />
            <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
            <title>{title}</title>
          </head>
          <body>
            <div id=\"root\"></div>
            <script type=\"module\" src=\"/src/main.tsx\"></script>
          </body>
        </html>
        """
    ).strip() + "\n"
    _write_file(out / "index.html", content)


def _write_main_tsx(src_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import React from "react";
        import ReactDOM from "react-dom/client";
        import App from "./App";
        import "./index.css";

        ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
          <React.StrictMode>
            <App />
          </React.StrictMode>
        );
        """
    ).strip() + "\n"
    _write_file(src_dir / "main.tsx", content)


def _write_index_css(src_dir: Path, app: App) -> None:
    styles = generate_styles(app)
    base = textwrap.dedent(
        """
        body {
          margin: 0;
          background-color: var(--background, #0f172a);
        }
        .n3-app {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background-color: var(--background, #ffffff);
          color: var(--text, #0f172a);
        }
        .n3-main {
          flex: 1 1 auto;
          padding: 2rem clamp(1rem, 4vw, 4rem);
          max-width: 1200px;
          width: 100%;
          margin: 0 auto;
        }
        .n3-nav {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
        }
        .n3-nav a {
          text-decoration: none;
          color: var(--text, #0f172a);
          font-weight: 600;
        }
        .n3-nav a.active {
          color: var(--primary, #2563eb);
        }
        .n3-widget {
          margin-bottom: 1.75rem;
          padding: 1.25rem;
          border-radius: 1rem;
          background-color: rgba(255, 255, 255, 0.95);
          box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
        }
        .n3-widget h3 {
          margin-top: 0;
        }
        .n3-toast {
          position: fixed;
          bottom: 1.5rem;
          right: 1.5rem;
          background: rgba(15, 23, 42, 0.92);
          color: #fff;
          padding: 0.75rem 1rem;
          border-radius: 0.75rem;
          box-shadow: 0 12px 32px rgba(15, 23, 42, 0.3);
        }
        table.n3-table {
          width: 100%;
          border-collapse: collapse;
        }
        table.n3-table th,
        table.n3-table td {
          border-bottom: 1px solid rgba(15, 23, 42, 0.08);
          padding: 0.65rem 0.75rem;
          text-align: left;
        }
        """
    ).strip()
    content = styles + "\n\n" + base + "\n"
    _write_file(src_dir / "index.css", content)


def _write_navigation(lib_dir: Path, nav_links: List[Dict[str, str]]) -> None:
    rendered = json.dumps(nav_links, indent=2)
    content = textwrap.dedent(
        f"""
        export interface NavLink {{
          label: string;
          path: string;
        }}

        export const NAV_LINKS: NavLink[] = {rendered} as const;
        """
    ).strip() + "\n"
    _write_file(lib_dir / "navigation.ts", content)


def _write_toast_component(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import { createContext, PropsWithChildren, useCallback, useContext, useMemo, useState } from "react";

        interface ToastContextValue {
          show: (message: string, timeoutMs?: number) => void;
        }

        const ToastContext = createContext<ToastContextValue>({
          show: () => undefined,
        });

        export function ToastProvider({ children }: PropsWithChildren) {
          const [message, setMessage] = useState<string | null>(null);
          const [timer, setTimer] = useState<number | undefined>(undefined);

          const show = useCallback((nextMessage: string, timeoutMs = 2800) => {
            setMessage(nextMessage);
            if (timer) {
              window.clearTimeout(timer);
            }
            const id = window.setTimeout(() => setMessage(null), timeoutMs);
            setTimer(id);
          }, [timer]);

          const value = useMemo<ToastContextValue>(() => ({ show }), [show]);

          return (
            <ToastContext.Provider value={value}>
              {children}
              {message ? <div className="n3-toast" role="status">{message}</div> : null}
            </ToastContext.Provider>
          );
        }

        export function useToast() {
          return useContext(ToastContext);
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "Toast.tsx", content)


def _write_layout_component(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import { NavLink } from "../lib/navigation";
        import { Link, useLocation } from "react-router-dom";
        import type { PropsWithChildren } from "react";

        interface LayoutProps {
          title: string;
          description?: string | null;
          navLinks: readonly NavLink[];
        }

        export default function Layout({ title, description, navLinks, children }: PropsWithChildren<LayoutProps>) {
          const location = useLocation();

          return (
            <div className="n3-app">
              <header style={{ padding: "1.25rem clamp(1rem, 4vw, 4rem)" }}>
                <h1 style={{ marginBottom: "0.25rem" }}>{title}</h1>
                {description ? <p style={{ marginTop: 0, color: "var(--text-muted, #475569)" }}>{description}</p> : null}
                <nav className="n3-nav">
                  {navLinks.map((link) => (
                    <Link key={link.path} to={link.path} className={location.pathname === link.path ? "active" : undefined}>
                      {link.label}
                    </Link>
                  ))}
                </nav>
              </header>
              <main className="n3-main">{children}</main>
            </div>
          );
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "Layout.tsx", content)


def _write_chart_widget(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import type { ChartWidgetConfig } from "../lib/n3Client";
        import { ensureArray } from "../lib/n3Client";

        interface ChartWidgetProps {
          widget: ChartWidgetConfig;
          data: unknown;
        }

        export default function ChartWidget({ widget, data }: ChartWidgetProps) {
          const labels = Array.isArray((data as any)?.labels) ? (data as any).labels as string[] : [];
          const datasets = ensureArray<{ label?: string; data?: unknown[] }>((data as any)?.datasets);

          return (
            <section className="n3-widget">
              <h3>{widget.title}</h3>
              {labels.length && datasets.length ? (
                <div>
                  {datasets.map((dataset, index) => (
                    <div key={dataset.label ?? index} style={{ marginBottom: "0.75rem" }}>
                      <strong>{dataset.label ?? `Series ${index + 1}`}</strong>
                      <ul style={{ listStyle: "none", paddingLeft: 0 }}>
                        {labels.map((label, idx) => (
                          <li key={label + idx}>
                            <span style={{ fontWeight: 500 }}>{label}:</span> {Array.isArray(dataset.data) ? dataset.data[idx] : "n/a"}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : (
                <pre style={{ marginTop: "0.75rem" }}>{JSON.stringify(data ?? widget, null, 2)}</pre>
              )}
            </section>
          );
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "ChartWidget.tsx", content)


def _write_table_widget(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import type { TableWidgetConfig } from "../lib/n3Client";

        interface TableWidgetProps {
          widget: TableWidgetConfig;
          data: unknown;
        }

        export default function TableWidget({ widget, data }: TableWidgetProps) {
          const rows = Array.isArray((data as any)?.rows) ? (data as any).rows as Record<string, unknown>[] : [];
          const columns = widget.columns && widget.columns.length ? widget.columns : rows.length ? Object.keys(rows[0]) : [];

          return (
            <section className="n3-widget">
              <h3>{widget.title}</h3>
              {rows.length ? (
                <div style={{ overflowX: "auto" }}>
                  <table className="n3-table">
                    <thead>
                      <tr>
                        {columns.map((column) => (
                          <th key={column}>{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((row, idx) => (
                        <tr key={idx}>
                          {columns.map((column) => (
                            <td key={column}>{String((row as any)[column] ?? "")}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <pre>{JSON.stringify(data ?? widget, null, 2)}</pre>
              )}
            </section>
          );
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "TableWidget.tsx", content)


def _write_form_widget(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import { FormEvent, useState } from "react";
        import type { FormWidgetConfig } from "../lib/n3Client";
        import { useToast } from "./Toast";

        interface FormWidgetProps {
          widget: FormWidgetConfig;
          pageSlug: string;
        }

        export default function FormWidget({ widget, pageSlug }: FormWidgetProps) {
          const toast = useToast();
          const [submitting, setSubmitting] = useState(false);

          async function handleSubmit(event: FormEvent<HTMLFormElement>) {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            const payload: Record<string, unknown> = {};
            form.forEach((value, key) => {
              payload[key] = value;
            });
            try {
              setSubmitting(true);
              const response = await fetch(`/api/pages/${pageSlug}/forms/${widget.id}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
              });
              if (!response.ok) {
                throw new Error(`Request failed: ${response.status}`);
              }
              toast.show(widget.successMessage ?? "Form submitted");
            } catch (error) {
              console.warn("Form submission failed", error);
              toast.show("Unable to submit form right now");
            } finally {
              setSubmitting(false);
            }
          }

          return (
            <section className="n3-widget">
              <h3>{widget.title}</h3>
              <form onSubmit={handleSubmit} style={{ display: "grid", gap: "0.75rem", maxWidth: "420px" }}>
                {widget.fields.map((field) => (
                  <label key={field.name} style={{ display: "grid", gap: "0.35rem" }}>
                    <span style={{ fontWeight: 600 }}>{field.name}</span>
                    <input name={field.name} type={field.type ?? "text"} required style={{ padding: "0.55rem 0.75rem", borderRadius: "0.5rem", border: "1px solid rgba(15,23,42,0.18)" }} />
                  </label>
                ))}
                <button type="submit" disabled={submitting} style={{ padding: "0.65rem 1.25rem", borderRadius: "0.65rem", border: "none", background: "var(--primary, #2563eb)", color: "#fff", fontWeight: 600 }}>
                  {submitting ? "Submitting..." : "Submit"}
                </button>
              </form>
            </section>
          );
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "FormWidget.tsx", content)


def _write_text_widget(components_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import type { CSSProperties } from "react";
        import type { TextWidgetConfig } from "../lib/n3Client";

        interface TextBlockProps {
          widget: TextWidgetConfig;
        }

        function normaliseStyles(styles: Record<string, string> | undefined): Record<string, string> {
          const result: Record<string, string> = {};
          if (!styles) {
            return result;
          }

          const sizeScale: Record<string, string> = {
            small: "0.875rem",
            medium: "1rem",
            large: "1.35rem",
            "x-large": "1.75rem",
            "xx-large": "2rem",
          };

          Object.entries(styles).forEach(([rawKey, rawValue]) => {
            const key = rawKey.toLowerCase();
            const value = rawValue;
            if (key === "align") {
              result.textAlign = value;
              return;
            }
            if (key === "weight") {
              const weight = value.toLowerCase();
              if (weight === "bold") {
                result.fontWeight = "700";
              } else if (weight === "light") {
                result.fontWeight = "300";
              } else if (weight === "normal") {
                result.fontWeight = "400";
              } else {
                result.fontWeight = value;
              }
              return;
            }
            if (key === "size") {
              const size = sizeScale[value.toLowerCase()] ?? value;
              result.fontSize = size;
              return;
            }
            const parts = rawKey.split(/[-_\s]+/).filter(Boolean);
            if (!parts.length) {
              return;
            }
            const camel = parts[0] + parts.slice(1).map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1)).join("");
            result[camel] = value;
          });
          return result;
        }

        export default function TextBlock({ widget }: TextBlockProps) {
          return (
            <section className="n3-widget" style={normaliseStyles(widget.styles) as CSSProperties}>
              <p style={{ margin: 0 }}>{widget.text}</p>
            </section>
          );
        }
        """
    ).strip() + "\n"
    _write_file(components_dir / "TextBlock.tsx", content)


def _write_realtime_hook(lib_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import { useEffect } from "react";
        import type { PageDefinition } from "./n3Client";

        export function useRealtimePage(definition: PageDefinition) {
          useEffect(() => {
            if (!definition.realtime || typeof window === "undefined") {
              return;
            }
            const slug = definition.slug;
            const protocol = window.location.protocol === "https:" ? "wss" : "ws";
            const host = window.location.host;
            const socket = new WebSocket(`${protocol}://${host}/ws/pages/${slug}`);
            socket.onmessage = (event) => {
              console.debug("namel3ss realtime", slug, event.data);
            };
            socket.onerror = (event) => {
              console.warn("namel3ss realtime error", event);
            };
            return () => {
              socket.close();
            };
          }, [definition.realtime, definition.slug]);
        }
        """
    ).strip() + "\n"
    _write_file(lib_dir / "realtime.ts", content)


def _write_client_lib(lib_dir: Path) -> None:
    content = textwrap.dedent(
        """
        import { useEffect, useState } from "react";

        export interface DataSourceRef {
          kind: string;
          name: string;
        }

        export interface TextWidgetConfig {
          id: string;
          type: "text";
          text: string;
          styles?: Record<string, string>;
        }

        export interface TableWidgetConfig {
          id: string;
          type: "table";
          title: string;
          columns: string[];
          source: DataSourceRef;
        }

        export interface ChartWidgetConfig {
          id: string;
          type: "chart";
          title: string;
          chartType?: string;
          source: DataSourceRef;
          x?: string | null;
          y?: string | null;
        }

        export interface FormWidgetField {
          name: string;
          type?: string;
        }

        export interface FormWidgetConfig {
          id: string;
          type: "form";
          title: string;
          fields: FormWidgetField[];
          successMessage?: string | null;
        }

        export type WidgetConfig =
          | TextWidgetConfig
          | TableWidgetConfig
          | ChartWidgetConfig
          | FormWidgetConfig;

        export interface PageDefinition {
          slug: string;
          route: string;
          title: string;
          description?: string | null;
          reactive: boolean;
          realtime: boolean;
          widgets: WidgetConfig[];
          preview: Record<string, unknown>;
        }

        export interface PageDataState {
          data: Record<string, unknown> | null;
          loading: boolean;
          error: string | null;
        }

        type UnknownRecord = Record<string, any>;

        function isRecord(value: unknown): value is UnknownRecord {
          return !!value && typeof value === "object" && !Array.isArray(value);
        }

        function cloneObjectArray(value: unknown, deep?: boolean): UnknownRecord[] {
          if (!Array.isArray(value)) {
            return [];
          }
          return (value as UnknownRecord[]).map((item) => {
            const source = isRecord(item) ? item : {};
            const clone: UnknownRecord = { ...source };
            if (deep) {
              if (Array.isArray(source.rows)) {
                clone.rows = cloneObjectArray(source.rows, true);
              }
              if (isRecord(source.summary)) {
                clone.summary = { ...source.summary };
              }
              if (isRecord(source.metadata)) {
                clone.metadata = { ...source.metadata };
              }
            }
            return clone;
          });
        }

        function cloneDataset(dataset: UnknownRecord): UnknownRecord {
          const clone: UnknownRecord = { ...dataset };
          if (Array.isArray(dataset.rows)) {
            clone.rows = cloneObjectArray(dataset.rows, true);
          }
          if (isRecord(dataset.summary)) {
            clone.summary = { ...dataset.summary };
          }
          if (isRecord(dataset.metadata)) {
            clone.metadata = { ...dataset.metadata };
          }
          return clone;
        }

        function normaliseRowId(row: UnknownRecord): string | null {
          const candidate = row.id ?? row.rowId ?? row.__id;
          if (candidate === undefined || candidate === null) {
            return null;
          }
          return String(candidate);
        }

        function upsertRows(base: UnknownRecord[], patches: UnknownRecord[]): UnknownRecord[] {
          if (!patches.length) {
            return base;
          }
          const result = base.map((row) => ({ ...row }));
          const byId = new Map<string, UnknownRecord>();
          result.forEach((row) => {
            const id = normaliseRowId(row);
            if (id !== null) {
              byId.set(id, row);
            }
          });
          patches.forEach((patch) => {
            const id = normaliseRowId(patch);
            if (id === null) {
              result.push({ ...patch });
              return;
            }
            const target = byId.get(id);
            if (target) {
              Object.assign(target, patch);
            } else {
              const clone = { ...patch };
              byId.set(id, clone);
              result.push(clone);
            }
          });
          return result;
        }

        function applyRowReplacements(base: UnknownRecord[], replacements: UnknownRecord): UnknownRecord[] {
          const keys = Object.keys(replacements ?? {});
          if (!keys.length) {
            return base;
          }
          const result = base.map((row) => ({ ...row }));
          const byId = new Map<string, UnknownRecord>();
          result.forEach((row) => {
            const id = normaliseRowId(row);
            if (id !== null) {
              byId.set(id, row);
            }
          });
          keys.forEach((key) => {
            const patch = replacements[key];
            if (!isRecord(patch)) {
              return;
            }
            const target = byId.get(key);
            if (target) {
              Object.assign(target, patch);
            } else {
              const clone: UnknownRecord = { id: key, ...patch };
              byId.set(key, clone);
              result.push(clone);
            }
          });
          return result;
        }

        function appendRowCollection(base: UnknownRecord[], additions: UnknownRecord[]): UnknownRecord[] {
          if (!additions.length) {
            return base;
          }
          return [...base, ...additions.map((row) => ({ ...row }))];
        }

        function mergeRowOverlays(baseRows: unknown, overlay: UnknownRecord): UnknownRecord[] | undefined {
          const hasDirectRows = Array.isArray(overlay.rows);
          let rows = hasDirectRows ? cloneObjectArray(overlay.rows) : Array.isArray(baseRows) ? cloneObjectArray(baseRows) : [];
          let mutated = hasDirectRows;

          const optimisticRows = cloneObjectArray(overlay.optimisticRows);
          if (optimisticRows.length) {
            rows = upsertRows(rows, optimisticRows);
            mutated = true;
          }

          const replaceRows = isRecord(overlay.replaceRows) ? overlay.replaceRows : {};
          if (Object.keys(replaceRows).length) {
            rows = applyRowReplacements(rows, replaceRows);
            mutated = true;
          }

          const appendRows = cloneObjectArray(overlay.appendRows);
          if (appendRows.length) {
            rows = appendRowCollection(rows, appendRows);
            mutated = true;
          }

          return mutated ? rows : undefined;
        }

        function mergeSummary(baseSummary: unknown, overlay: unknown): UnknownRecord | undefined {
          const direct = isRecord(overlay) ? overlay : undefined;
          if (!direct) {
            return isRecord(baseSummary) ? { ...baseSummary } : undefined;
          }
          const base = isRecord(baseSummary) ? { ...baseSummary } : {};
          Object.assign(base, direct);
          return base;
        }

        function mergeMetadata(baseMetadata: unknown, overlay: unknown): UnknownRecord | undefined {
          const direct = isRecord(overlay) ? overlay : undefined;
          if (!direct) {
            return isRecord(baseMetadata) ? { ...baseMetadata } : undefined;
          }
          const base = isRecord(baseMetadata) ? { ...baseMetadata } : {};
          Object.assign(base, direct);
          return base;
        }

        function mergeDatasetOverlays(baseDatasets: unknown, overlays: unknown): UnknownRecord[] | undefined {
          if (!Array.isArray(overlays) || overlays.length === 0) {
            return undefined;
          }
          const result = Array.isArray(baseDatasets)
            ? (baseDatasets as UnknownRecord[]).map((dataset) => cloneDataset(dataset))
            : [];
          const index = new Map<string, UnknownRecord>();
          result.forEach((dataset) => {
            const key = dataset.id ?? dataset.name;
            if (key !== undefined && key !== null) {
              index.set(String(key), dataset);
            }
          });
          (overlays as UnknownRecord[]).forEach((candidate) => {
            if (!isRecord(candidate)) {
              return;
            }
            const datasetPatch = candidate as UnknownRecord;
            const keyValue = datasetPatch.id ?? datasetPatch.name;
            if (keyValue === undefined || keyValue === null) {
              result.push(cloneDataset(datasetPatch));
              return;
            }
            const key = String(keyValue);
            const target = index.get(key);
            if (!target) {
              const clone = cloneDataset(datasetPatch);
              index.set(key, clone);
              result.push(clone);
              return;
            }
            const rowOverlay = mergeRowOverlays(target.rows, datasetPatch);
            if (rowOverlay) {
              target.rows = rowOverlay;
            }
            const summaryOverlay = mergeSummary(target.summary, datasetPatch.optimisticSummary ?? datasetPatch.summary);
            if (summaryOverlay) {
              target.summary = summaryOverlay;
            }
            const metadataOverlay = mergeMetadata(target.metadata, datasetPatch.metadata);
            if (metadataOverlay) {
              target.metadata = metadataOverlay;
            }
            Object.entries(datasetPatch).forEach(([field, value]) => {
              if (
                field === "id" ||
                field === "name" ||
                field === "optimisticRows" ||
                field === "appendRows" ||
                field === "replaceRows" ||
                field === "optimisticSummary" ||
                field === "metadata"
              ) {
                return;
              }
              if (field === "rows" && Array.isArray(value)) {
                target.rows = cloneObjectArray(value);
                return;
              }
              if (field === "summary" && isRecord(value)) {
                target.summary = { ...value };
                return;
              }
              if (field === "metadata" && isRecord(value)) {
                target.metadata = { ...value };
                return;
              }
              target[field] = value;
            });
          });
          return result;
        }

        function mergeOptimisticData(base: unknown, optimistic: unknown): unknown {
          if (optimistic === undefined || optimistic === null) {
            return base;
          }
          if (!isRecord(optimistic)) {
            return optimistic;
          }
          const patch = optimistic as UnknownRecord;
          const baseRecord: UnknownRecord = isRecord(base) ? { ...base } : {};
          let mutated = false;
          if (Object.prototype.hasOwnProperty.call(patch, "pending")) {
            baseRecord.pending = patch.pending;
            mutated = true;
          }
          if (Object.prototype.hasOwnProperty.call(patch, "error")) {
            baseRecord.error = patch.error;
            mutated = true;
          }
          const dataOverlay = isRecord(patch.data) ? (patch.data as UnknownRecord) : undefined;
          if (dataOverlay) {
            const rowOverlay = mergeRowOverlays(baseRecord.rows, dataOverlay);
            if (rowOverlay) {
              baseRecord.rows = rowOverlay;
              mutated = true;
            }
            const datasetsOverlay = mergeDatasetOverlays(baseRecord.datasets, dataOverlay.optimisticDatasets);
            if (datasetsOverlay) {
              baseRecord.datasets = datasetsOverlay;
              mutated = true;
            }
            const summaryOverlay = mergeSummary(baseRecord.summary, dataOverlay.optimisticSummary ?? dataOverlay.summary);
            if (summaryOverlay) {
              baseRecord.summary = summaryOverlay;
              mutated = true;
            }
            const metadataOverlay = mergeMetadata(baseRecord.metadata, dataOverlay.metadata);
            if (metadataOverlay) {
              baseRecord.metadata = metadataOverlay;
              mutated = true;
            }
            Object.entries(dataOverlay).forEach(([field, value]) => {
              if (
                field === "optimisticRows" ||
                field === "appendRows" ||
                field === "replaceRows" ||
                field === "optimisticSummary" ||
                field === "optimisticDatasets" ||
                field === "metadata" ||
                field === "rows" ||
                field === "summary"
              ) {
                return;
              }
              baseRecord[field] = value;
              mutated = true;
            });
          }
          return mutated ? baseRecord : base;
        }

        export function usePageData(definition: PageDefinition): PageDataState {
          const [state, setState] = useState<PageDataState>({ data: null, loading: true, error: null });

          useEffect(() => {
            let cancelled = false;
            setState({ data: null, loading: true, error: null });
            fetch(`/api/pages/${definition.slug}`, {
              headers: { Accept: "application/json" },
            })
              .then((response) => {
                if (!response.ok) {
                  throw new Error(`Request failed: ${response.status}`);
                }
                return response.json();
              })
              .then((payload) => {
                if (!cancelled) {
                  setState({ data: payload ?? {}, loading: false, error: null });
                }
              })
              .catch((error) => {
                if (!cancelled) {
                  setState({ data: null, loading: false, error: error instanceof Error ? error.message : String(error) });
                }
              });
            return () => {
              cancelled = true;
            };
          }, [definition.slug]);

          return state;
        }

        export function resolveWidgetData(widgetId: string, pageData: Record<string, unknown> | null | undefined): unknown {
          if (!pageData || typeof pageData !== "object") {
            return undefined;
          }
          const buckets = [
            (pageData as any).widgets,
            (pageData as any).components,
            (pageData as any).data,
          ];
          let resolved: unknown = undefined;
          for (const bucket of buckets) {
            if (bucket && typeof bucket === "object" && widgetId in bucket) {
              resolved = (bucket as Record<string, unknown>)[widgetId];
              break;
            }
          }
          if (resolved === undefined && widgetId in (pageData as Record<string, unknown>)) {
            resolved = (pageData as Record<string, unknown>)[widgetId];
          }
          const optimisticRoot = (pageData as any).optimistic;
          if (!optimisticRoot || typeof optimisticRoot !== "object") {
            return resolved;
          }
          const optimisticEntry = (optimisticRoot as Record<string, unknown>)[widgetId];
          if (optimisticEntry === undefined) {
            return resolved;
          }
          return mergeOptimisticData(resolved, optimisticEntry);
        }

        export function ensureArray<T>(value: unknown): T[] {
          return Array.isArray(value) ? (value as T[]) : [];
        }
        """
    ).strip() + "\n"
    _write_file(lib_dir / "n3Client.ts", content)


def _write_app_tsx(src_dir: Path, page_builds: List[ReactPage]) -> None:
    imports = [f"import {build.component_name} from \"./pages/{build.file_name}\";" for build in page_builds]
    routes: List[str] = []
    for build in page_builds:
        routes.append(f"          <Route path=\"{build.primary_route}\" element={{<{build.component_name} />}} />")
        for extra in build.extra_routes:
            routes.append(f"          <Route path=\"{extra}\" element={{<{build.component_name} />}} />")
    routes.append("          <Route path=\"*\" element={<Navigate to=\"/\" replace />} />")

    template = textwrap.dedent(
        """
        import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
        import { ToastProvider } from "./components/Toast";
        __IMPORTS__

        export default function App() {
          return (
            <ToastProvider>
              <BrowserRouter>
                <Routes>
        __ROUTES__
                </Routes>
              </BrowserRouter>
            </ToastProvider>
          );
        }
        """
    ).strip()

    content = template.replace("__IMPORTS__", "\n".join(imports)).replace("__ROUTES__", "\n".join(routes)) + "\n"
    _write_file(src_dir / "App.tsx", content)


def _write_page_component(pages_dir: Path, build: ReactPage) -> None:
    definition = json.dumps(build.definition, indent=2)
    template = textwrap.dedent(
        """
        import Layout from "../components/Layout";
        import ChartWidget from "../components/ChartWidget";
        import TableWidget from "../components/TableWidget";
        import FormWidget from "../components/FormWidget";
        import TextBlock from "../components/TextBlock";
        import { NAV_LINKS } from "../lib/navigation";
        import { PageDefinition, resolveWidgetData, usePageData } from "../lib/n3Client";
        import { useRealtimePage } from "../lib/realtime";

        const PAGE_DEFINITION: PageDefinition = __DEFINITION__ as const;

        export default function __COMPONENT__() {
          const { data, loading, error } = usePageData(PAGE_DEFINITION);
          useRealtimePage(PAGE_DEFINITION);

          return (
            <Layout title={PAGE_DEFINITION.title} description={PAGE_DEFINITION.description} navLinks={NAV_LINKS}>
              {loading ? (
                <p>Loading page data...</p>
              ) : error ? (
                <p role="alert">Failed to load page: {error}</p>
              ) : (
                <div style={{ display: "grid", gap: "1.25rem" }}>
                  {PAGE_DEFINITION.widgets.map((widget) => {
                    const widgetData = resolveWidgetData(widget.id, data) ?? PAGE_DEFINITION.preview[widget.id];
                    if (widget.type === "text") {
                      return <TextBlock key={widget.id} widget={widget} />;
                    }
                    if (widget.type === "chart") {
                      return <ChartWidget key={widget.id} widget={widget} data={widgetData} />;
                    }
                    if (widget.type === "table") {
                      return <TableWidget key={widget.id} widget={widget} data={widgetData} />;
                    }
                    if (widget.type === "form") {
                      return <FormWidget key={widget.id} widget={widget} pageSlug={PAGE_DEFINITION.slug} />;
                    }
                    return null;
                  })}
                </div>
              )}
            </Layout>
          );
        }
        """
    ).strip()

    content = template.replace("__DEFINITION__", definition).replace("__COMPONENT__", build.component_name) + "\n"
    _write_file(pages_dir / f"{build.file_name}.tsx", content)


def _write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
