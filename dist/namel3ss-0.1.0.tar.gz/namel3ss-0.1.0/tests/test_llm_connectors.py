"""Tests for provider-specific LLM connector behaviour with mocked HTTP flows."""

from __future__ import annotations

import types
from typing import Dict

import pytest

from namel3ss.codegen.backend import generate_backend
from namel3ss.parser import Parser

from tests.backend_test_utils import load_backend_module


@pytest.fixture
def runtime_module(tmp_path, monkeypatch):
    source = (
        'app "LLMTest".\n'
        '\n'
        'connector "openai" type llm:\n'
        '  provider = "openai"\n'
        '  model = "gpt-4o-mini"\n'
        '\n'
        'connector "anthropic" type llm:\n'
        '  provider = "anthropic"\n'
        '  model = "claude-3-sonnet"\n'
        '\n'
        'connector "azure" type llm:\n'
        '  provider = "openai"\n'
        '  model = "gpt-4o"\n'
        '  deployment = "gpt-prod"\n'
        '  api_base = "https://example.azure.com/openai"\n'
        '\n'
        'page "Home" at "/":\n'
        '  show text "Hello"\n'
    )
    app = Parser(source).parse()
    backend_dir = tmp_path / "backend_llm"
    generate_backend(app, backend_dir)

    with load_backend_module(tmp_path, backend_dir, monkeypatch) as module:
        yield module


@pytest.fixture(autouse=True)
def _patch_ai_connectors(runtime_module):
    runtime = runtime_module.runtime
    runtime.AI_CONNECTORS = {
        "openai": {
            "config": {
                "provider": "openai",
                "model": "gpt-4o-mini",
                "api_key_env": "OPENAI_API_KEY",
                "max_response_chars": 50,
            }
        },
        "anthropic": {
            "config": {
                "provider": "anthropic",
                "model": "claude-3-sonnet",
                "api_key_env": "ANTHROPIC_API_KEY",
                "system": "You are testing",
            }
        },
        "azure": {
            "config": {
                "provider": "openai",
                "model": "gpt-4o",
                "deployment": "gpt-prod",
                "api_key_env": "AZURE_OPENAI_KEY",
                "api_base": "https://example.azure.com/openai",
                "api_version": "2024-05-01-preview",
            }
        },
    }
    runtime.ENV_KEYS = [
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "AZURE_OPENAI_KEY",
    ]
    return runtime.AI_CONNECTORS


class _DummyResponse:
    def __init__(self, payload: Dict[str, object]) -> None:
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> Dict[str, object]:
        return self._payload


class _ClientRecorder:
    def __init__(self) -> None:
        self.calls = []

    def __enter__(self) -> "_ClientRecorder":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        payload = {
            "choices": [
                {
                    "message": {
                        "content": "Hello from test",
                    }
                }
            ],
            "usage": {"total_tokens": 42},
        }
        if "anthropic.com" in url:
            payload = {
                "content": [
                    {
                        "type": "text",
                        "text": "Anthropic mock response",
                    }
                ]
            }
        if "deployments" in url:
            payload = {
                "choices": [
                    {
                        "text": "Azure deployment text",
                    }
                ]
            }
        return _DummyResponse(payload)


@pytest.fixture(autouse=True)
def _mock_http_client(monkeypatch, runtime_module):
    mock_client_cls = types.SimpleNamespace()
    mock_client_cls.__call__ = lambda *args, **kwargs: _ClientRecorder()

    def _factory(*_args, **_kwargs):
        return _ClientRecorder()

    monkeypatch.setattr(runtime_module.runtime.httpx, "Client", _factory)
    return _factory


@pytest.fixture(autouse=True)
def _set_env(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-openai")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-anthropic")
    monkeypatch.setenv("AZURE_OPENAI_KEY", "test-azure")


def test_openai_connector_returns_trimmed_text(runtime_module):
    result = runtime_module.call_llm_connector("openai", {"prompt": "Greetings"})
    assert result["status"] == "ok"
    assert result["result"] == "Hello from test"
    assert result["provider"] == "openai"
    assert result["usage"] == {"total_tokens": 42}


def test_anthropic_connector_formats_messages(runtime_module):
    result = runtime_module.call_llm_connector("anthropic", {"prompt": "Explain"})
    assert result["status"] == "ok"
    assert "Anthropic mock response" in result["result"]
    assert result["provider"] == "anthropic"


def test_azure_deployment_connector_builds_endpoint(runtime_module):
    result = runtime_module.call_llm_connector("azure", {"prompt": "Azure"})
    assert result["status"] == "ok"
    assert result["result"] == "Azure deployment text"
    assert result["provider"] == "openai"
    assert "raw_response" in result
